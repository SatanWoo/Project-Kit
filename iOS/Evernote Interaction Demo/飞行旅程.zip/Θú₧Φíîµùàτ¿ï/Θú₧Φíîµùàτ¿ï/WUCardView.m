//
//  WUCardView.m
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-15.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import "WUCardView.h"
#import <QuartzCore/QuartzCore.h>

#define kDefaultCornerRadius 5.0
#define kDefaultAnimationDuration 0.3
#define kDefaultMaximizedScalingFactor 1.0
#define kDefaultCardNaviagtionBarHeight self.navigationController.navigationBar.frame.size.height;

@interface WUCardView()

@property (nonatomic, assign) int cardIndex;
@property (nonatomic, assign) CGFloat originY;
@property (nonatomic, assign) CGFloat scale;

- (void)shrinkCardToScale;
- (void)expandCardToFullScreen;

@end

@implementation WUCardView
@synthesize containerViewController = _containerViewController;
@synthesize navigationController = _navigationController;
@synthesize delegate = _delegate;
@synthesize datasource = _datasource;
@synthesize state = _state;
@synthesize origin = _origin;
@synthesize percentageDistanceMovedFromOrigin = _percentageDistanceMovedFromOrigin;

@synthesize cardIndex = _cardIndex;
@synthesize originY = _originY;
@synthesize scale = _scale;

- (id)initCardView:(UIViewController *)containerViewController navigationController:(UINavigationController *)navigationController cardIndex:(NSInteger)index
{
    if (self = [super initWithFrame:navigationController.view.bounds]) {
        self.navigationController = navigationController;
        self.containerViewController = containerViewController;
        self.state = WUCardViewStateDefault;
        self.cardIndex = index;
        
        [self addSubview:navigationController.view];
        
        [self.navigationController.view.layer setCornerRadius:kDefaultCornerRadius];
        [self.navigationController.view setClipsToBounds:YES];
        
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureCallbackSelector:)];
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureCallbackSelector:)];
        
        [self.navigationController.navigationBar addGestureRecognizer:panGesture];
        [self.navigationController.navigationBar addGestureRecognizer:tapGesture];
    }
    return self;
}

- (void)updateState:(WUCardViewState)state
{
    [UIView animateWithDuration:kDefaultAnimationDuration animations:^{
        if (state == WUCardViewStateFullScreen) {
            [self expandCardToFullScreen];
            [self resetOrignY:0];
        } else if (state == WUCardViewStateDefault) {
            [self shrinkCardToScale];
            [self resetOrignY:self.originY];
        } else if (state == WUCardViewStateHideCardBelow) {
            [self resetOrignY:self.containerViewController.view.frame.size.height + 45];
        }
        
        WUCardViewState lastState = self.state;
        self.state = state;
        if ([self.delegate respondsToSelector:@selector(cardView:didChangeToDisplayState:fromState:)]) {
            [self.delegate cardView:self didChangeToDisplayState:state fromState:lastState];
        }
    }];
}

- (void)resetOrignY:(CGFloat)y
{
    CGRect oldFrame = self.frame;
    oldFrame.origin.y = y;
    self.frame = oldFrame;
}

#pragma mark - Override Getter & Setter
- (CGPoint)origin
{
    return CGPointMake(0, self.originY);
}

- (CGFloat)percentageDistanceMovedFromOrigin
{
    return self.frame.origin.y / self.originY;
}

- (void)setDatasource:(id<WUCardViewDatasource>)datasource
{
    _datasource = datasource;
    
    self.originY = [_datasource cardOriginPosition:self.cardIndex];
    self.scale = [_datasource cardScale:self.cardIndex];
    [self updateState:WUCardViewStateDefault];
}

#pragma mark - UIGestureRecognizer 
- (void)panGestureCallbackSelector:(UIPanGestureRecognizer *)panGestureRecognizer
{
    CGPoint location = [panGestureRecognizer locationInView:self.containerViewController.view];
    CGPoint translation = [panGestureRecognizer translationInView:self];
    
    if (panGestureRecognizer.state == UIGestureRecognizerStateBegan) {
        // Fuck 
    } else if (panGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        if (translation.y > 0) { 
            if (self.state == WUCardViewStateFullScreen && self.frame.origin.y < self.originY) {
                if ([self.delegate respondsToSelector:@selector(cardView:didUpdatePanPercentage:)] ){
                    [self.delegate cardView:self didUpdatePanPercentage:self.percentageDistanceMovedFromOrigin];
                }
            } else if (self.state == WUCardViewStateDefault && self.frame.origin.y > self.originY) {
                if ([self.delegate respondsToSelector:@selector(cardView:didUpdatePanPercentage:)]) {
                    [self.delegate cardView:self didUpdatePanPercentage:self.percentageDistanceMovedFromOrigin];
                }
            }
        }
        [self resetOrignY:location.y];
    } else if (panGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        if ([self shouldReturnToState:self.state fromMovedPoint:[panGestureRecognizer translationInView:self]]) {
            [self updateState:self.state];
        } else {
            WUCardViewState newState = (self.state == WUCardViewStateFullScreen) ? WUCardViewStateDefault : WUCardViewStateFullScreen;
            [self updateState:newState];
        }
    }
}

- (void)tapGestureCallbackSelector:(UIGestureRecognizer *)tapGestureRecognizer
{
    if (self.state == WUCardViewStateDefault) {
        [self updateState:WUCardViewStateFullScreen];
    }
}

#pragma mark - Private method
- (void)shrinkCardToScale
{
    self.transform = CGAffineTransformMakeScale(self.scale, self.scale);
}

- (void)expandCardToFullScreen
{
    self.transform = CGAffineTransformMakeScale(kDefaultMaximizedScalingFactor, kDefaultMaximizedScalingFactor);
}

- (BOOL)shouldReturnToState:(WUCardViewState)state fromMovedPoint:(CGPoint)movedPoint
{
    if (self.state == WUCardViewStateDefault) {
        return movedPoint.y > -kDefaultCardNaviagtionBarHeight;
    } else if (self.state == WUCardViewStateFullScreen) {
        return movedPoint.y < kDefaultCardNaviagtionBarHeight;
    }
    
    return NO;
}

@end
