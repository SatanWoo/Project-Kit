//
//  WUCardView.h
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-15.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WUCardView;

typedef enum
{
    WUCardViewStateDefault = 0,
    WUCardViewStateFullScreen = 1,
    WUCardViewStateHideCardBelow = 2,
} WUCardViewState;

@protocol WUCardViewDatasource <NSObject>
@required
- (CGFloat)cardOriginPosition:(int)index;
- (CGFloat)cardScale:(int)index;
@end

@protocol WUCardViewDelegate <NSObject>
@optional
// To Implement the effect of move card below or above together
- (void)cardView:(WUCardView *)cardView didChangeToDisplayState:(WUCardViewState)toState fromState:(WUCardViewState)fromState;
- (void)cardView:(WUCardView *)cardView didUpdatePanPercentage:(CGFloat)percentage;
@end

@interface WUCardView : UIView

@property (nonatomic, strong) UINavigationController *navigationController;
@property (nonatomic, strong) UIViewController *containerViewController;
@property (nonatomic, weak)   id<WUCardViewDelegate> delegate;
@property (nonatomic, weak)   id<WUCardViewDatasource> datasource;
@property (nonatomic, assign) WUCardViewState state;
@property (nonatomic, assign, readonly) CGPoint origin;
@property (nonatomic, assign, readonly) CGFloat percentageDistanceMovedFromOrigin;

- (id)initCardView:(UIViewController *)containerViewController navigationController:(UINavigationController *)navigationController cardIndex:(NSInteger)index;
- (BOOL)shouldReturnToState:(WUCardViewState)state fromMovedPoint:(CGPoint)movedPoint;
- (void)updateState:(WUCardViewState)state;
- (void)resetOrignY:(CGFloat)y;
@end
