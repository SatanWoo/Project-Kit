//
//  WUTestViewController.h
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-16.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import "WUCardBaseViewController.h"

@interface WUTestViewController : WUCardBaseViewController
@property (nonatomic, strong) NSArray* viewControllerData;
@end
