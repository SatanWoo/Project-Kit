//
//  WUContentRootViewController.m
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-16.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import "WUContentRootViewController.h"

@interface WUContentRootViewController ()

@end

@implementation WUContentRootViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationItem setTitle:[self.info objectForKey:@"title"]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
