//
//  WUTestViewController.m
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-16.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import "WUTestViewController.h"
#import "WUContentRootViewController.h"

@interface WUTestViewController ()

@end

@implementation WUTestViewController

#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    NSString* plistPath = [[NSBundle mainBundle] pathForResource: @"NavigationControllerData"
                                                          ofType: @"plist"];
    self.viewControllerData = [[NSArray alloc] initWithContentsOfFile:plistPath];
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Template Method
- (int)numberOfCardOfView
{
    return [self.viewControllerData count];
}

- (UIViewController *)contentRootViewControllerForCard:(int)indexPath
{
    NSDictionary* navDict = [self.viewControllerData objectAtIndex:indexPath];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:[NSBundle mainBundle]];
    
    WUContentRootViewController* viewController = [storyboard instantiateViewControllerWithIdentifier:@"RootViewController"];
    viewController.info = navDict;

    return viewController;
}
@end
