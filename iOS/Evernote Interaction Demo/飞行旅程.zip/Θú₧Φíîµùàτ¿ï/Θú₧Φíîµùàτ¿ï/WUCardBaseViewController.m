//
//  WUCardBaseViewController.m
//  飞行旅程
//
//  Created by Ziqi Wu on 13-1-15.
//  Copyright (c) 2013年 Ziqi Wu. All rights reserved.
//

#import "WUCardBaseViewController.h"
#import "WUCardView.h"

#define kDefaultMinimizedScalingFactor 0.98
#define kDefaultNavigationControllerToolbarHeight 44
#define kDefaultOrigin 100  
#define kDefaultNavigationBarOverlap 0.90   

@interface WUCardBaseViewController ()<WUCardViewDatasource, WUCardViewDelegate>
@property (nonatomic, assign) int totalCardViews;
@property (nonatomic, strong) NSMutableArray *cardsArray;

- (void)configureCardView; //Try Design Pattern : Template Method
- (NSArray *)cardsBelowMovedCard:(WUCardView *)card;
- (NSArray *)cardsAboveMovedCard:(WUCardView *)card;
- (void)clearAllCards;
@end

@implementation WUCardBaseViewController
@synthesize totalCardViews = _totalCardViews;
@synthesize cardsArray = _cardsArray;

#pragma mark - View LifeCycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self configureCardView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self clearAllCards];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Override Getter
- (NSMutableArray *)cardsArray
{
    if (_cardsArray == nil) {
        _cardsArray = [[NSMutableArray alloc] init];
    }
    return _cardsArray;
}

#pragma mark - Template Method To be overriden
- (int)numberOfCardOfView
{
    return 0;
}

- (UIViewController *)contentRootViewControllerForCard:(int)indexPath
{
    return nil;
}

#pragma mark - WUCardViewDatasource
- (CGFloat)cardOriginPosition:(int)index
{
    CGFloat originOffset = 0;
    for (int i = 0; i < index; i ++) {
        CGFloat scalingFactor = [self cardScale:i];
        originOffset += scalingFactor * kDefaultNavigationControllerToolbarHeight * kDefaultNavigationBarOverlap;
    }
    return kDefaultOrigin + originOffset;
}

- (CGFloat)cardScale:(int)index
{
    return powf(kDefaultMinimizedScalingFactor, (self.totalCardViews - index));
}

#pragma mark - WUCardViewDelegate
- (void)cardView:(WUCardView *)cardView didChangeToDisplayState:(WUCardViewState)toState fromState:(WUCardViewState)fromState
{
    if (fromState == WUCardViewStateDefault && toState == WUCardViewStateFullScreen) {
        for (WUCardView *card in [self cardsBelowMovedCard:cardView]) {
            [card updateState:WUCardViewStateHideCardBelow];
        }
    } else if (fromState == WUCardViewStateFullScreen && toState == WUCardViewStateDefault) {
        for (WUCardView *card in [self cardsAboveMovedCard:cardView]) {
            [card updateState:WUCardViewStateDefault];
        }
        for (WUCardView *card in [self cardsBelowMovedCard:cardView]) {
            [card updateState:WUCardViewStateDefault];
        }
    } else if (fromState == WUCardViewStateDefault && toState == WUCardViewStateDefault) {
        for (WUCardView *card in [self cardsBelowMovedCard:cardView]) {
            [card updateState:WUCardViewStateDefault];
        }
    }
}

- (void)cardView:(WUCardView *)cardView didUpdatePanPercentage:(CGFloat)percentage
{
    if (cardView.state == WUCardViewStateFullScreen) {
        for (WUCardView *card in [self cardsAboveMovedCard:cardView]) {
            [card resetOrignY:card.origin.y * percentage];
        }
    } else if (cardView.state == WUCardViewStateDefault) {
        for (WUCardView *card in [self cardsBelowMovedCard:cardView]) {
            CGFloat deltaDistance = cardView.frame.origin.y - cardView.origin.y;
            [card resetOrignY:card.origin.y + deltaDistance];
        }
    }
}

#pragma mark - Private Method

- (void)clearAllCards
{
    for (WUCardView *card in self.cardsArray) {
        [card removeFromSuperview];
    }
}

- (void)configureCardView
{
    self.totalCardViews = [self numberOfCardOfView];
    for (int i = 0 ; i < self.totalCardViews; i++) {
        UIViewController *viewControllere = [self contentRootViewControllerForCard:i];
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:viewControllere];
        
        WUCardView *card = [[WUCardView alloc] initCardView:self navigationController:navigationController cardIndex:i];
        card.delegate = self;
        card.datasource = self;
        [self.cardsArray addObject:card];
    }
    
    for (WUCardView *card in self.cardsArray) {
        [self.view addSubview:card];
    }
}

- (NSArray *)cardsAboveMovedCard:(WUCardView *)card
{
    NSInteger index = [self.cardsArray indexOfObject:card];
    return [self.cardsArray filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(WUCardView *otherCard, NSDictionary *bindings) {
        return [self.cardsArray indexOfObject:otherCard] < index;
    }]];
}

- (NSArray *)cardsBelowMovedCard:(WUCardView *)card
{
    NSInteger index = [self.cardsArray indexOfObject:card];
    return [self.cardsArray filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(WUCardView *otherCard, NSDictionary *bindings) {
        return [self.cardsArray indexOfObject:otherCard] > index;
    }]];

}

@end
