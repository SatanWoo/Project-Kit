
This is a DXF library that currently supports entity tree construction and export of this tree to DXF format. 
So, in essence, it is a DXF generator for now. 

I have written the library a long time ago for a project for my father. It doesn't contain unit tests - I didn't know what that is back then :) - but it is well written and has been used extensivly very succesfuly in that software.

If you look around the code you will see that everything is simple and clear.

There is an usage example in EXAMPLE.txt.

If you like it and/or use it please let me know. It will me make all worm and fuzzy :)

If you are having any problems with it, also let me know. I will not get worm and fuzzy but I will try to help out.

The license is MIT so you can use it however you want as long as you mention me somewhere.

Enjoy! :)