% Makefile
% run
% >> make
% in MATLAB for compile the c++ files.

mex icpCpp.cpp
mex kdtree.cc