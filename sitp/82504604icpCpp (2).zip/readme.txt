ICPCPP

This ICP file collection contains the icpCpp function and also the kdtree function,
which is used for creating the kd-tree. The kdtree code is written by Guy Shechter and is
downloaded for free at

http://www.mathworks.com/matlabcentral/fileexchange/loadFile.do?objectId=4586&objectType=file

The source-code files are included, as well as precompiled mex files for Windows.

Compile the source-code files by running

make

in MATLAB�s command window.

A demostration of the usage of icpCpp is found in icp_demo. Run icp_demo
in MATLAB and the example point matching is done.

/Per Bergstr�m  2007-10-04

per.bergstrom@ltu.se


